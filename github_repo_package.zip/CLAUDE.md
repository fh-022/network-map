# HANDOFF — Dealer Network Platform (read this first)

You are continuing work on a bespoke, offline, single-file HTML dealer network planning platform built for automotive importer consulting (Colmobil context, "Yaakov" market-entry program CZ/SK/CH, market AT added). The user is Felix. This document is the complete context transfer from the previous work environment.

## What this is
- **dealer_network_platform.html** — the product. Fully self-contained (Leaflet via CDN), runs offline from disk. 2,359 dealers across CZ/SK/CH/AT, drive-time coverage model, scenario planning, dealer funnel, PPT/Excel exports in Colmobil CI.
- **CZ_SK_CH_Dealership_Overview_v3_merged_with_research_status.xlsx** — the master data workbook (Locations, Dealership Groups, Completeness, Research Status sheets). Single source of truth for dealer data.

## How to rebuild the platform (the only two commands that matter)
```
python3 prep_v5.py <path-to-workbook.xlsx>   # parses workbook -> locations_v5.json / groups_v5.json, geocodes, reports misses
python3 build_v5.py                          # assembles template_v5.html + app_v5.js + export_v5.js + libs -> dealer_network_platform.html
```
Geocode misses print as `! (MARKET, name, address)` — fix by adding towns to gazetteer_v5.json (name → [lat,lon]) and re-running. Market-ambiguous names go into gazetteer_mkt.json as "Name|CC" or PLZ-qualified "Name|AT5".

## File map
- template_v5.html / app_v5.js / export_v5.js — UI, logic, PPT export (pptxgen). Engine in _reuse_engine.js (Dijkstra over synthetic road graph), density in _reuse_density.js, disclaimer in _reuse_disc.js.
- demand_munis.json (861 municipalities ≥5k, 4 countries) · road_graph.json (894 nodes / 1,290 edges, minutes per edge) · regional_weights.json (motorization factors, sourced) · gazetteer_v5.json + gazetteer_mkt.json + district_gazetteer.json (geocoding) · cities_v4.json (map labels).
- ingest_pplx.py / merge_apply.py / rebuild_completeness.py / at_ingest_v2.py — research ingestion pipeline (Perplexity results → workbook).
- docs/: UX_REVIEW.md (feature critique + roadmap), DATA_UPDATE_REPORT.md (sources & epistemics), FRAGMENTATION_REPORT.md, PPT_EXPORT_REPORT.md, WORKSPACE_AND_CUSTOMS_REPORT.md.

## Hard conventions (user preferences — do not violate)
- No em dashes in any user-facing text or data.
- Tool language English; Colmobil CI for PPT (petrol #023F40, green #00CD55, Assistant font, 16:9).
- Market colors: CZ #2c66ad, SK #c05a35, CH #3f9d5c, AT #6b4fa0. Accent #008CC8.
- Workbook formatting: Arial 10, thin borders — new rows must copy the style of existing rows (openpyxl default style is a known past bug).
- Brand tags in workbook: "Brand [S]" sales / "[SV]" service / "[U]" used; commas inside [..] — split with regex `,(?![^\[]*\])`.
- Decisions are confirmed with Felix before implementation; he expects questions before assumptions on defaults, grain, scope.

## Data epistemics (be careful)
- Dealer data mixes verified (official locators/PDFs, tagged [S]/[SV] + source column) and legacy/unverified rows. The Research Status sheet tracks per brand×market.
- **Fabrication history**: an earlier Perplexity session invented plausible dealer tables (e.g., Porsche Inter Auto locations listed as Toyota dealers). All AT data was therefore re-gathered source-first with guard-block prompts. Never merge research output without spot-checking against this pattern; never fuzzy-match into used-car chains (AAA Auto/AURES) without company-name evidence.
- AT municipal populations: top layer verified (Wien 2,005,760 ZMR 1.1.2024), tail knowledge-based ±10%. Motorization weights fully sourced (Statistik Austria 2024). Drive times: synthetic graph, ±20-30%, no German transit corridors by design.
- AT remaining research gaps: Toyota (~110 partners, zero enumerated), Kia, Hyundai beyond Denzel, Ayvens PDF (obtainable via servus@ayvens.com).

## Current feature state & backlog
Just shipped: usability pass (active-filter chips, self-documenting KPI, coverage build-up caption, empty-state guide, filter accordions) and **dealer funnel Phase 1** (group-level stages with location override per program brand, brand lens in top bar, funnel map coloring, contracted-network KPI). Funnel lives in WS.funnel ('g:Group'/'l:id' keys), stages prospect→contacted→pitched→LOI→contracted→live + declined, log in WS.funnelLog.

**Next up (agreed with Felix):**
1. Funnel Phase 2: gate targets per country×brand (WS.gates, coverage % AND dealer count, either binds), gap-to-gate widget, funnel columns + bulk edit in Directory, per-place brand checkboxes + multi-brand overlay.
2. UX medium tier (UX_REVIEW.md §priorities): Exports home, directory show-on-map + edited-cell marking, export preview thumbnail, directory virtualization.
3. Later: gate evidence pack (one-click PPT per country×brand), candidate scoring, weekly delta mode (funnelLog snapshots), light Asana CSV handshake (Asana owns tasks, tool owns network state — do not build task management into the tool).

## Program context (why features look the way they do)
The tool supports the "Yaakov" market-entry program: 856 activities, 13 work packages, gates per country×brand ("dealer network contracted + go-live ready"). The tool owns the Network Development workstream: strategy (coverage cases), screening (Directory), pitch (PPT exports), contracting progress (funnel), gate evidence (KPI). Program brands are anonymized as Brand A/B/C in the tool (renameable via lens bar ✎).

## Testing
Previous environment used headless Chromium regression tests (workspace migration, coverage values, cross-border drive times: Wien–Bratislava ~42 min, Praha CZ-case regression 28.4% @40min single place). Re-establish equivalent smoke tests in this environment before shipping changes; always verify old workspaces load unchanged (localStorage key `dnp_workspace_v1`, migrate() in app_v5.js).
