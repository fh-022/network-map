# Dealer Network Platform
Offline single-file HTML platform for dealer network planning & program steering (CZ/SK/CH/AT).
- **dealer_network_platform.html** — the product (open in any browser, works offline)
- **CLAUDE.md** — full project context, conventions, and backlog (Claude Code reads this automatically)
- platform/ — source + geodata + build pipeline (see platform/REBUILD.md)
- data-pipeline/ — master workbook + research ingestion scripts
- docs/ — reports (UX review, data sources & epistemics, exports)
- research/ — Perplexity prompt packs
